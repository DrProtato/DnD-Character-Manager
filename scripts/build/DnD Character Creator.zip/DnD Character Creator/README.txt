Run the main.exe file to start the program.  

Make sure to fill out the google form:
https://forms.gle/9fgYEUe3YCUD566b9
